<?php get_header(); ?>


<!-- Main -->
	
	<div class="container-404">
	   <h2 class="page-heading">404 Error!</h2>
	   <br>
	   <img src="http://source.unsplash.com/400x300/?cats" alt="" />
	   <h3>Opps! I think you got lost. Please try the following links.</h3>
	   <ul>
		  <li><a href="<?php echo site_url("/home") ?>">Home Page</a></li>
		  <li><a href="<?php echo site_url("/blog") ?>">Blog List</a></li>
		  <li><a href="<?php echo site_url("/projects") ?>">Projects List</a></li>
		  <li><a href="<?php echo site_url("/about") ?>">About</a></li>
		</ul>
	</div>
		

<?php get_footer(); ?>		