<footer>
			<div id="footer-left">
				<h3><u>Quick Links</u></h3>
				<p>
					<ul>
						<li>
							<a href="<?php echo site_url(""); ?>">Home</a>
						</li>
						<li>
				            <a href="<?php echo site_url("/blog"); ?>">Blog</a>
			            </li>
						<li>
							<a href="<?php echo site_url("/projects"); ?>">Projects</a>
						</li>
						<li>
							<a href="<?php echo site_url("/about"); ?>">About</a>
						</li>
						<li>
							<a href="<?php echo site_url("/privacy-policy"); ?>">Privacy Policy</a>
						</li>
						<li>
							<a href="<?php echo site_url("/contact"); ?>">Contact</a>
						</li>
					</ul>
				</p>
			</div>
			<div id="footer-right">
				<h3>Follow us on</h3>
				<div class="social-media-footer">
					<ul>
						<li>
							<a href="#">
								<i class="fab fa-facebook"></i>
							</a>
						</li>
						<li>
							<a href="#">
								<i class="fab fa-youtube"></i>
							</a>
						</li>
						<li>
							<a href="#">
								<i class="fab fa-github"></i>
							</a>
						</li>
					</ul>
				</div>
				<p>This website is developed by KatTypeM Productions &#169 <span class="copyright-year"></span></p>
			</div>
		</footer>
		
		
	</main>
	<?php wp_footer(); ?>
	
	<script src="main.js"></script>
</body>
</html>