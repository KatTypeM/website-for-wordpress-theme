<?php

//adding CSS and JS files
function ktm_setup(){
    wp_enqueue_style('google-fonts', '//fonts.googleapis.com/css2?family=News+Cycle&display=swap');
    wp_enqueue_style('google-fonts', '//fonts.googleapis.com/css2?family=Roboto&display=swap');
    wp_enqueue_style('fontawesome', '//cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');
    wp_enqueue_style('style', get_stylesheet_uri());
    //change microtime to version number after finished developement
    wp_enqueue_script("main", get_theme_file_uri("/js/main.js"), NULL, "1.0.0", true);
}
add_action('wp_enqueue_scripts', 'ktm_setup');

// adding theme support
function ktm_initial(){
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('custom-header');
    add_theme_support('custom-background');
    // shows title tag on each page
    add_theme_support('title-tag');
    add_theme_support('html5',
        array('comment-list', 'comment-form', 'search-form')
    );
    
    add_theme_support('editor-color-palette');
    add_theme_support('editor-gradient-presets');
    add_theme_support('editor-font-sizes');
    add_theme_support('editor-styles');
    add_theme_support( 'post-formats', 
	    array(
	    'aside', 
		'gallery',
		'link',
		'image',
		'quote',
		'status',
		'video',
		'audio',
		'chat'
    	) 
    );
    add_post_type_support( 'post', 'post-formats' );
    add_post_type_support( 'page', 'post-formats' );
}
add_action('after_setup_theme', 'ktm_initial');


// Projects post
function ktm_custom_post_type(){
    register_post_type('project',
        array(
            'rewrite' => array('slug' => 'projects'),
            'labels' => array(
                'name' => 'Projects',
                'singular_name' => 'Project',
                'add_new_item' => 'Add New Project',
                'edit_item' => 'Edit Project'
            ),
            'menu-icon' => 'dashicons-clipboard',
            'public' => true,
            'has_archive' => true,
            'supports' => array(
                'title', 'thumbnail', 'editor', 'excerpt', 'comments'
            ),
            'taxonomies'          => array( 'category' )
        )
    );
}
add_action('init', 'ktm_custom_post_type');



// add sidebar widget support
function ktm_custom_widgets(){
    register_sidebar(
        array(
            "name" => "Main Sidebar",
            "id" => "main_sidebar",
            "before_title" => "<h3>",
            "after_title" => "</h3>"
            )
        );
}
add_action("widgets_init", "ktm_custom_widgets");

// filters for search
function search_filter($query){
    if($query->is_search()){
        $query->set("post_type", array("post", "projects"));
    }
}
add_filter("pre_get_posts", "search");






































?>